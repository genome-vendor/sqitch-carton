SET client_min_messages = warning;
DROP TABLE IF EXISTS __myapp.widgets;
