use 5.010;

print while <STDIN>;
