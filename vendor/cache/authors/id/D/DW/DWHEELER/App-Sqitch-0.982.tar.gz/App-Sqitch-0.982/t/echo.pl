use 5.010;

say "@ARGV";
